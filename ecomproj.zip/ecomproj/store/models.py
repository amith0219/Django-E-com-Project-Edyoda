from django.db import models
from django.contrib.auth.models import User
from django.shortcuts import reverse
from django.db.models import Avg,Count
    

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(blank=True, max_length=20)
    address = models.CharField(blank=True, max_length=150)
    city = models.CharField(blank=True, max_length=20)
    state = models.CharField(blank=True, max_length=50)

    def __str__(self):
        return self.user.first_name
    
    


class Category(models.Model):
    name = models.CharField(max_length=30)
    description = models.TextField()

    def __str__(self):
        return self.name


class Product(models.Model):
    name = models.CharField(max_length=200)
    desc = models.TextField(max_length=250)
    details = models.TextField(max_length=250, null=True, blank=True)
    price = models.FloatField()
    stock = models.IntegerField(default=0)
    discount_price = models.FloatField(blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    image = models.ImageField(null=True, blank=True)
    slug = models.SlugField(blank=True)

    def __str__(self):
        return self.name

    

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url
    

    def averagereview(self):
        reviews = Comment.objects.filter(product=self, status='New').aggregate(average=Avg('rate'))
        avg=0
        if reviews["average"] is not None:
            avg=float(reviews["average"])    
        return avg


    
    def countreview(self):
        reviews = Comment.objects.filter(product=self, status='New').aggregate(count=Count('id'))
        cnt=0
        if reviews["count"] is not None:
            cnt = int(reviews["count"])
        return cnt

   

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    quantity = models.IntegerField(default=1)


    def __str__(self):
        return self.product.name

    
    def price(self):
        return self.product.price


    def total(self):
        total = self.quantity * self.product.price
        return total





class Order(models.Model):
    STATUS = (('Accepted','Accepted'),)


    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    first_name = models.CharField(max_length=20, null=True)
    last_name = models.CharField(max_length=20, null=True)
    phone = models.CharField(blank=True, max_length=10)
    address = models.CharField(blank=True, max_length=150)
    city = models.CharField(blank=True, max_length=20)
    state = models.CharField(blank=True, max_length=20)
    total = models.IntegerField()
    status=models.CharField(max_length=10,choices=STATUS,default='Accepted')
    adminnote = models.CharField(blank=True, max_length=100)
    create_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.first_name


class OrderProduct(models.Model):
    STATUS = (('Accepted','Accepted'),)

    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.IntegerField()
    total = models.IntegerField()
    status = models.CharField(max_length=10, choices=STATUS, default='Accepted')
    create_at = models.DateTimeField(auto_now_add=True)


    def __str__(self):
        return self.product.name
    



    




    
class Comment(models.Model):
    STATUS = (
        ('New', 'New'),
        ('True', 'True'),
        ('False', 'False'),
    )
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    subject = models.CharField(max_length=50, blank=True)
    rate = models.IntegerField(default=1)
    status = models.CharField(max_length=10, choices=STATUS, default='New')
    comment = models.CharField(max_length=250, blank=True)
    create_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.subject
    