from django.shortcuts import render,get_object_or_404,redirect
from store.models import *
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.views.generic import DetailView,ListView
from django.http import HttpResponse,HttpResponseRedirect
from django.views import View
from django.contrib.auth.forms import PasswordChangeForm
from .forms import CommentForm,CartForm,OrderForm,Order,SearchForm
from django.contrib import messages
from .forms import UserRegisterForm,ProfileUpdateForm,UserUpdateForm
from django.urls import reverse,reverse_lazy
# Create your views here.

def store(request):
     products = Product.objects.all()
     category = Category.objects.all()
     context = {'products':products, 'category':category}
     return render(request, 'store/store.html', context)


def index2(request, id):
     cat = Category.objects.all()
     post = Product.objects.filter(category_id = id)
     return render(request,"store/store.html",context = {"products":post, "category":cat})


@login_required(login_url='/login')
def userprofile(request):
     current_user = request.user  
     profile = UserProfile.objects.get(user_id=current_user.id)
     context = {'profile':profile}
     return render(request, "store/userprofile.html", context)



@login_required(login_url='/login') 
def userupdate(request):
     if request.method == 'POST':
          user_form = UserUpdateForm(request.POST, instance=request.user) 
          profile_form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user.userprofile)
          if user_form.is_valid() and profile_form.is_valid(): 
               user_form.save()
               profile_form.save()
               messages.success(request, 'Your Profile has been Updated!')
               return HttpResponseRedirect('/userprofile')
     else:
          category = Category.objects.all()
          user_form = UserUpdateForm(instance=request.user)
          profile_form = ProfileUpdateForm(instance=request.user.userprofile) 
          context = {'category': category,'user_form': user_form,'profile_form': profile_form}
          return render(request, 'store/userupdate.html', context)




def user_password(request):
     if request.method == 'POST':
          form = PasswordChangeForm(request.user, request.POST)
          if form.is_valid():
               user = form.save()
               update_session_auth_hash(request, user)  # Important!
               messages.success(request, 'Your password was successfully Updated!')
               return HttpResponseRedirect('/userprofile')
          else:
               messages.error(request, 'Please correct the error below.<br>'+ str(form.errors))
               return HttpResponseRedirect('/userprofile/password')
     else:
          form = PasswordChangeForm(request.user)
          return render(request, 'store/password_update.html', {'form': form})






def orderproduct(request):
     category = Category.objects.all()
     current_user = request.user
     shopcart = Cart.objects.filter(user_id=current_user.id)
     total=0
     for rs in shopcart:
          total += rs.product.price * rs.quantity

     if request.method == 'POST':
          form = OrderForm(request.POST)
          if form.is_valid():
               data = Order()
               data.first_name = form.cleaned_data['first_name']
               data.last_name = form.cleaned_data['last_name']
               data.address = form.cleaned_data['address']
               data.city = form.cleaned_data['city']
               data.phone = form.cleaned_data['phone']
               data.user_id = current_user.id 
               data.total = total
               data.save()

               for rs in shopcart:
                    detail = OrderProduct()
                    detail.order_id     = data.id 
                    detail.product_id   = rs.product_id 
                    detail.user_id      = current_user.id  
                    detail.quantity     = rs.quantity
                    detail.price        = rs.product.price
                    detail.total        = rs.total 
                    detail.save()
                    print(detail)
                    product = Product.objects.get(id=rs.product_id)
                    product.stock -= rs.quantity
                    product.save()
               Cart.objects.filter(user_id=current_user.id).delete()
               request.session['cart_items']=0
               messages.success(request, "Your Order has been Placed!!. Thank You ")
               return render(request,'store/ordercomplete.html', {'category':category})
          else:
               messages.warning(request, form.errors)
               return HttpResponseRedirect("/orderproduct")

     form = OrderForm()
     profile = UserProfile.objects.get(user_id=current_user.id)
     context = {'shopcart': shopcart, 'category':category,'total': total, 'form':form,'profile':profile,}
     return render(request, 'store/Order_Form.html', context)






def product_detail(request, id):
     category = Category.objects.all()
     product = Product.objects.get(pk=id)
     comments = Comment.objects.filter(product_id=id,status='New')
     context = {'product':product, 'category':category,'comments':comments,}
     return render(request,'store/product.html',context)



def checkout(request):
     curent_user = request.user
     shopcart = Cart.objects.filter(user_id=curent_user.id)
     total=0
     for rs in shopcart:
          total += rs.product.price * rs.quantity
     context = {'shopcart': shopcart,'total': total,}
     return render(request, 'store/checkout.html', context)




def register(request):    
     if request.method == 'POST':
         form = UserRegisterForm(request.POST)
         if form.is_valid():
              form.save()
              username = form.cleaned_data.get('username')
              messages.success(request, f'Your account has been created! You are now able to log in')
              return redirect('login')
     else:
          form = UserRegisterForm()
     return render(request, 'registration/register.html', {'form': form})



def addcomment(request, id):
     url = request.META.get('HTTP_REFERER')
     if request.method == 'POST':
          form = CommentForm(request.POST)
          if form.is_valid():
               data = Comment()
               data.subject = form.cleaned_data['subject']
               data.comment = form.cleaned_data['comment']
               data.rate = form.cleaned_data['rate']
               data.product_id=id
               current_user = request.user
               data.user_id=current_user.id 
               data.save()
               messages.success(request, "Your Ratings has been submitted!")
               return HttpResponseRedirect(url)
     return HttpResponseRedirect(url)


@login_required(login_url="login")
def addtocart(request,id):
     url = request.META.get('HTTP_REFERER')
     current_user = request.user
     product = Product.objects.get(pk=id)

     checkinproduct = Cart.objects.filter(product_id=id, user_id=current_user.id)
     if checkinproduct:
          control = 1
     else:
          control = 0
     if request.method == 'POST':
          form = CartForm(request.POST)
          if form.is_valid():
               if control==1:
                    data = Cart.objects.get(product_id=id, user_id=current_user.id)
                    data.quantity += form.cleaned_data['quantity']
                    data.save()
               else:
                    data = Cart()
                    data.user_id = current_user.id
                    data.product_id = id
                    data.quantity = form.cleaned_data['quantity']
                    data.save()
          messages.success(request, "Product is added to your Cart!!")
          return HttpResponseRedirect(url)
     else:
          if control == 1:
               data = Cart.objects.get(product_id=id, user_id=current_user.id)
               data.quantity += 1
               data.save()
          else:
               data = Cart()
               data.user_id = current_user.id
               data.product_id = id
               data.quantity = 1
               data.save()
          messages.success(request, "Product is added to your Cart!!")
          return HttpResponseRedirect(url)


@login_required(login_url='/login') 
def deletefromcart(request,id):
    Cart.objects.filter(id=id).delete()
    messages.success(request, "Your item deleted from Cart.")
    return HttpResponseRedirect("/cart")




def cart(request):
     curent_user = request.user
     shopcart = Cart.objects.filter(user_id=curent_user.id)
     total=0
     for rs in shopcart:
          total += rs.product.price * rs.quantity
     context = {'shopcart': shopcart,'total': total,}
     return render(request, 'store/cart.html', context)



def search(request):
     if request.method == 'POST':
          form = SearchForm(request.POST)
          if form.is_valid():
               query = form.cleaned_data['query']
               catid = form.cleaned_data['catid']
               if catid==0:
                    products = Product.objects.filter(name__icontains=query)
               else:
                    products = Product.objects.filter(name__icontains=query,category_id=catid)

               category = Category.objects.all()
               context = {'products': products, 'category': category}
               return render(request, 'store/search_products.html', context)

     return HttpResponseRedirect('/')




def user_order_product(request):
     current_user = request.user
     order_product = OrderProduct.objects.filter(user_id=current_user.id).order_by('-id')
     context = {'order_product': order_product,}
     return render(request, 'store/user_order_products.html', context)


def user_order_product_detail(request,id,oid):
     current_user = request.user
     order = Order.objects.get(user_id=current_user.id, id=oid)
     orderitems = OrderProduct.objects.filter(id=id,user_id=current_user.id)
     context = {'order': order,'orderitems': orderitems,}
     return render(request, 'store/user_order_detail.html', context)
