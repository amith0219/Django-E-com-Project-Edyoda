from django.contrib import admin
from store.models import *
# Register your models here.


class CommentAdmin(admin.ModelAdmin):
    list_display = ['subject','comment','status','create_at']
    list_filter = ['status']
    readonly_fields = ('subject','comment','user','rate','product',)


class CartAdmin(admin.ModelAdmin):
    list_display = ['product','user','quantity','price','total']
    list_filter = ['user']
 

class OrderProductline(admin.TabularInline):
    model = OrderProduct
    readonly_fields = ('user', 'product','price','quantity','total')
    can_delete = False
    extra = 0


class OrderAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name','phone','city','total','status']
    list_filter = ['status']
    readonly_fields = ('user','address','city','state','phone','first_name', 'last_name','phone','city','total')
    can_delete = False
    inlines = [OrderProductline]

class OrderProductAdmin(admin.ModelAdmin):
    list_display = ['user', 'product','price','quantity','total']
    list_filter = ['user']


class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['address', 'phone','city','state']


admin.site.register(Category)
admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(Product)
admin.site.register(Order, OrderAdmin)
admin.site.register(Cart, CartAdmin)
admin.site.register(Comment, CommentAdmin)
admin.site.register(OrderProduct, OrderProductAdmin)